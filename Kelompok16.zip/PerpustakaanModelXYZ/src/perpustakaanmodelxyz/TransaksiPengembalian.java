/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package perpustakaanmodelxyz;

import java.util.Date;

/**
 *
 * @author ACER
 */
public class TransaksiPengembalian {
     private int IdTransaksi;

    public int getIdTransaksi() {
        return IdTransaksi;
    }

    public void setIdTransaksi(int IdTransaksi) {
        this.IdTransaksi = IdTransaksi;
    }

    public Buku getBuku() {
        return buku;
    }

    public void setBuku(Buku buku) {
        this.buku = buku;
    }

    public AngotaPerpustakaan getAnggota() {
        return anggota;
    }

    public void setAnggota(AngotaPerpustakaan anggota) {
        this.anggota = anggota;
    }

    public Date getTanggal() {
        return tanggal;
    }

    public void setTanggal(Date tanggal) {
        this.tanggal = tanggal;
    }
   private Buku buku;
   private AngotaPerpustakaan anggota;
   private Date tanggal;

    public TransaksiPengembalian(int IdTransaksi, Buku buku, AngotaPerpustakaan anggota, Date tanggal) {
        this.IdTransaksi = IdTransaksi;
        this.buku = buku;
        this.anggota = anggota;
        this.tanggal = tanggal;
    }
}
