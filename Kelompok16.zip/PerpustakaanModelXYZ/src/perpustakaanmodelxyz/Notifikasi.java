/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package perpustakaanmodelxyz;

/**
 *
 * @author ACER
 */
public class Notifikasi {
    static void notifikasipengembalian(){
        System.out.println("Pengembalikan buku dilakukan");
    }
    static void notifikasipeminjaman(){
        System.out.println("Peminjaman buku dilakukan");
    }
}
