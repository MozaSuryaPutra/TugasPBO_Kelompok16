/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package perpustakaanmodelxyz;

/**
 *
 * @author ACER
 */
public class Buku {
private String judul;
    private int noISBN;
    private String pengarang;
    private boolean tersedia;

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public int getNoISBN() {
        return noISBN;
    }

    public void setNoISBN(int noISBN) {
        this.noISBN = noISBN;
    }

    public String getPengarang() {
        return pengarang;
    }

    public void setPengarang(String pengarang) {
        this.pengarang = pengarang;
    }

    public boolean isTersedia() {
        return tersedia;
    }

    public void setTersedia(boolean tersedia) {
        this.tersedia = tersedia;
    }
    public Buku(String judul, int noISBN, String pengarang, boolean tersedia) {
        this.judul = judul;
        this.noISBN = noISBN;
        this.pengarang = pengarang;
        this.tersedia = tersedia;
    }

    
    
    
    
}
